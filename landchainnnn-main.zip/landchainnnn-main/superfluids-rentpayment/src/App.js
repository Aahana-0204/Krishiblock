import "./styles.css";

import { CreateFlow } from "./CreateFlow";

export default function App() {
  return (
    <div className="App">
      <CreateFlow />
    </div>
  );
}
