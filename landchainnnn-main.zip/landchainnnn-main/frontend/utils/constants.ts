export const DEV = process.env.NODE_ENV === 'development';

export const contractAddress = '00x9D8EADD37bB2A6aaAB62e209AFbFf41b08eD5e77';
