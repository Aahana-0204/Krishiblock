import { NextPage } from 'next';

const AllLandInspectors: NextPage = () => {
    return (
        <>
            All Land Inspector
        </>
    );
};

export default AllLandInspectors;